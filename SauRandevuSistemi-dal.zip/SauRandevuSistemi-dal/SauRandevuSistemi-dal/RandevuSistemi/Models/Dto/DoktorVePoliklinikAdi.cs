﻿using RandevuSistemi.Models.Entities;

namespace RandevuSistemi.Models.Dto
{
    public class DoktorVePoliklinikAdi
    {
        public Doktor doctor { get; set; }
        public string PoliklinikAdi { get; set; }
    }
}
