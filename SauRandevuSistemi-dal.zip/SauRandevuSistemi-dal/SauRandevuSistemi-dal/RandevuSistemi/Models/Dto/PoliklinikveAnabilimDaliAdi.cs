﻿using RandevuSistemi.Models.Entities;

namespace RandevuSistemi.Models.Dto
{
    public class PoliklinikveAnabilimDaliAdi
    {
        public Poliklinik poliklinik { get; set; }

        public string AnaBilimDaliAdi { get; set; }

    }
}
