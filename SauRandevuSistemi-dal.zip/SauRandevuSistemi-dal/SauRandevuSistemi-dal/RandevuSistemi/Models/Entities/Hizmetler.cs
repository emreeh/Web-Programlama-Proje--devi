﻿using System;
namespace RandevuSistemi.Models.Entities
{
	public class Hizmetler
	{
		public int Id { get; set; }
		public string HizmetAdi { get; set; }
	}
}

